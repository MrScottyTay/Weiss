# Weiß
Weiß (pronounced Weeb)
